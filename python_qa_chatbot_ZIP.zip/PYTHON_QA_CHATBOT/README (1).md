
# Personal Python Question-Answering Chatbot

## Project Description

This project develops a simple personal chatbot that answers questions related to Python programming using a predefined Python knowledge base.

## Features

- Accepts Python-related questions in natural language
- Uses a predefined Python knowledge base
- Uses TF-IDF for text representation
- Uses cosine similarity to find the most relevant question
- Provides an appropriate answer
- Supports interactive question-and-answer sessions

## Technologies Used

- Python
- Scikit-learn
- TF-IDF
- Cosine Similarity
- Google Colab

## How to Run

1. Open the `Python_QA_Chatbot.ipynb` notebook in Google Colab.
2. Run the cells from top to bottom.
3. The chatbot knowledge base will be created.
4. Enter Python-related questions when prompted.
5. Type `exit` to end the chatbot.

## Example Questions

- What is Python?
- What is a list?
- What is a function?
- What is inheritance?
- What is a dictionary?
- How to print in Python?
- What is Pandas?

## Conclusion

The Personal Python Question-Answering Chatbot provides relevant answers to Python-related questions using a predefined knowledge base and NLP-based similarity matching.
